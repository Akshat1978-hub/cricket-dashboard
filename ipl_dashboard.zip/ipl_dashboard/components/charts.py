"""
components/charts.py — Plotly chart builders for IPL Dashboard
"""

import plotly.graph_objects as go
import plotly.express as px
from utils import get_team_color, ALL_TEAMS

# ─── Theme Defaults ────────────────────────────────────────────────────────────

CHART_BG   = "#111120"
PAPER_BG   = "#0a0a12"
GRID_COLOR = "rgba(255,255,255,0.05)"
TEXT_COLOR = "#8888aa"
FONT_FAMILY = "DM Sans, sans-serif"


def _base_layout(title: str = "", height: int = 380) -> dict:
    return dict(
        title=dict(text=title, font=dict(family="Syne, sans-serif", size=16, color="#f0f0fa"), x=0.02),
        plot_bgcolor=CHART_BG,
        paper_bgcolor=PAPER_BG,
        font=dict(family=FONT_FAMILY, color=TEXT_COLOR),
        height=height,
        margin=dict(l=20, r=20, t=48, b=20),
        legend=dict(
            bgcolor="rgba(0,0,0,0)",
            bordercolor="rgba(255,255,255,0.1)",
            borderwidth=1,
            font=dict(size=11),
        ),
        xaxis=dict(showgrid=False, zeroline=False, tickfont=dict(size=11)),
        yaxis=dict(gridcolor=GRID_COLOR, zeroline=False, tickfont=dict(size=11)),
    )


# ─── Team Runs Bar Chart ──────────────────────────────────────────────────────

def team_runs_bar(match_data: list) -> go.Figure:
    """Bar chart comparing team totals across recent matches."""
    teams, runs, colors, names = [], [], [], []

    for m in match_data:
        scores = m.get("score", [])
        for s in scores:
            inning = s.get("inning", "")
            team_name = inning.replace(" Inning 1", "").replace(" Inning 2", "")
            r = s.get("r", 0)
            teams.append(team_name[:20])
            runs.append(r)
            colors.append(get_team_color(team_name, "primary"))
            names.append(m.get("name", "")[:30])

    if not teams:
        fig = go.Figure()
        fig.update_layout(**_base_layout("Team Runs Comparison"))
        return fig

    fig = go.Figure(go.Bar(
        x=teams,
        y=runs,
        marker=dict(
            color=colors,
            opacity=0.85,
            line=dict(color="rgba(255,255,255,0.1)", width=1),
        ),
        customdata=names,
        hovertemplate="<b>%{x}</b><br>Runs: %{y}<br>Match: %{customdata}<extra></extra>",
        text=runs,
        textposition="outside",
        textfont=dict(color="#f0f0fa", size=11, family="Syne, sans-serif"),
    ))
    fig.update_layout(**_base_layout("🏏 Team Runs Comparison"))
    fig.update_xaxes(tickangle=-25)
    return fig


# ─── Performance Line Chart ───────────────────────────────────────────────────

def team_performance_line(players: list) -> go.Figure:
    """Line chart showing top batsmen's runs across matches (simulated trend)."""
    import random
    random.seed(42)

    # Group by team and pick top scorers
    top_teams = ["Mumbai Indians", "Chennai Super Kings", "Royal Challengers Bengaluru",
                 "Kolkata Knight Riders", "Rajasthan Royals"][:5]
    matches = [f"M{i}" for i in range(1, 8)]

    fig = go.Figure()
    for team in top_teams:
        base = random.randint(120, 185)
        vals = [base + random.randint(-20, 30) for _ in matches]
        color = get_team_color(team)
        fig.add_trace(go.Scatter(
            x=matches, y=vals,
            mode="lines+markers",
            name=team[:20],
            line=dict(color=color, width=2.5, shape="spline"),
            marker=dict(color=color, size=7, symbol="circle",
                        line=dict(color="rgba(255,255,255,0.2)", width=1)),
            hovertemplate=f"<b>{team[:20]}</b><br>%{{x}}: %{{y}} runs<extra></extra>",
            fill="tozeroy",
            fillcolor=f"rgba({_hex_to_rgb(color)},0.06)",
        ))

    fig.update_layout(**_base_layout("📈 Team Performance Trend", height=400))
    return fig


def _hex_to_rgb(hex_color: str) -> str:
    h = hex_color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return f"{r},{g},{b}"
    except Exception:
        return "200,200,200"


# ─── Player Runs Leaderboard ──────────────────────────────────────────────────

def player_runs_chart(players: list) -> go.Figure:
    """Horizontal bar — top 10 run scorers."""
    sorted_p = sorted(players, key=lambda p: p.get("runs", 0), reverse=True)[:10]
    names  = [p["name"].split()[-1] for p in sorted_p]
    runs   = [p.get("runs", 0) for p in sorted_p]
    teams  = [p.get("team", "") for p in sorted_p]
    colors = [get_team_color(t) for t in teams]

    fig = go.Figure(go.Bar(
        y=names, x=runs,
        orientation="h",
        marker=dict(color=colors, opacity=0.85, line=dict(color="rgba(0,0,0,0.2)", width=1)),
        customdata=teams,
        hovertemplate="<b>%{y}</b> (%{customdata})<br>Runs: %{x}<extra></extra>",
        text=runs,
        textposition="inside",
        textfont=dict(color="white", size=11, family="Syne, sans-serif"),
    ))
    layout = _base_layout("🏅 Top Run Scorers", height=360)
    layout["yaxis"]["autorange"] = "reversed"
    fig.update_layout(**layout)
    return fig


def player_wickets_chart(players: list) -> go.Figure:
    """Horizontal bar — top 10 wicket takers."""
    bowlers = [p for p in players if p.get("wickets", 0) > 0]
    sorted_p = sorted(bowlers, key=lambda p: p.get("wickets", 0), reverse=True)[:10]
    if not sorted_p:
        fig = go.Figure()
        fig.update_layout(**_base_layout("🎯 Top Wicket Takers"))
        return fig

    names  = [p["name"].split()[-1] for p in sorted_p]
    wkts   = [p.get("wickets", 0) for p in sorted_p]
    teams  = [p.get("team", "") for p in sorted_p]
    colors = [get_team_color(t, "accent") or get_team_color(t) for t in teams]

    fig = go.Figure(go.Bar(
        y=names, x=wkts,
        orientation="h",
        marker=dict(color=colors, opacity=0.85),
        customdata=teams,
        hovertemplate="<b>%{y}</b> (%{customdata})<br>Wickets: %{x}<extra></extra>",
        text=wkts, textposition="inside",
        textfont=dict(color="white", size=11, family="Syne, sans-serif"),
    ))
    layout = _base_layout("🎯 Top Wicket Takers", height=360)
    layout["yaxis"]["autorange"] = "reversed"
    fig.update_layout(**layout)
    return fig


def team_composition_donut(players: list, team: str) -> go.Figure:
    """Donut showing role distribution for a team."""
    team_players = [p for p in players if p.get("team", "") == team]
    from collections import Counter
    roles = Counter(p.get("role", "Other") for p in team_players)
    labels = list(roles.keys())
    values = list(roles.values())
    color_map = {
        "Batsman": "#e8c94d",
        "Bowler": "#00e676",
        "All-Rounder": "#448aff",
        "WK-Batsman": "#ff6b6b",
    }
    colors = [color_map.get(l, "#888888") for l in labels]

    fig = go.Figure(go.Pie(
        labels=labels, values=values,
        hole=0.6,
        marker=dict(colors=colors, line=dict(color=CHART_BG, width=3)),
        hovertemplate="<b>%{label}</b>: %{value} players<extra></extra>",
        textfont=dict(family="Syne, sans-serif", size=12),
    ))
    fig.add_annotation(
        text=f"<b>{len(team_players)}</b><br><span style='font-size:10px'>Players</span>",
        x=0.5, y=0.5, showarrow=False, font=dict(size=20, color="#f0f0fa", family="Syne, sans-serif"),
        align="center"
    )
    fig.update_layout(**_base_layout(f"Squad Composition — {team.split()[-1]}", height=320))
    return fig
