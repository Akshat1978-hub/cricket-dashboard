"""
pages/player_stats.py — Player Stats Tab
"""

import streamlit as st
from components.cards import player_card_html
from components.charts import player_runs_chart, player_wickets_chart
from utils import ALL_TEAMS, get_team_color


def render(players: list):
    st.markdown('<div class="section-heading">🧑‍💻 Player Statistics</div>', unsafe_allow_html=True)

    # ─── Charts Row ───────────────────────────────────────────────────────────
    c1, c2 = st.columns(2)
    with c1:
        fig = player_runs_chart(players)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    with c2:
        fig2 = player_wickets_chart(players)
        st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar": False})

    st.markdown("<br>", unsafe_allow_html=True)

    # ─── Filter Controls ──────────────────────────────────────────────────────
    col_team, col_role, col_sort = st.columns([2, 2, 1])
    with col_team:
        all_player_teams = sorted({p.get("team", "") for p in players if p.get("team")})
        team_f = st.selectbox("Filter by team", ["All Teams"] + all_player_teams, key="ps_team",
                              label_visibility="visible")
    with col_role:
        all_roles = sorted({p.get("role", "") for p in players if p.get("role")})
        role_f = st.selectbox("Filter by role", ["All Roles"] + all_roles, key="ps_role",
                              label_visibility="visible")
    with col_sort:
        sort_by = st.selectbox("Sort by", ["Runs", "Wickets", "Avg"], key="ps_sort",
                               label_visibility="visible")

    # Apply filters
    filtered = players
    if team_f != "All Teams":
        filtered = [p for p in filtered if p.get("team") == team_f]
    if role_f != "All Roles":
        filtered = [p for p in filtered if p.get("role") == role_f]

    sort_map = {"Runs": "runs", "Wickets": "wickets", "Avg": "avg"}
    filtered = sorted(filtered, key=lambda p: p.get(sort_map[sort_by], 0), reverse=True)

    st.markdown(f"<div style='color:#8888aa;font-size:12px;margin:8px 0 16px'>{len(filtered)} players found</div>",
                unsafe_allow_html=True)

    # ─── Player Grid ──────────────────────────────────────────────────────────
    st.markdown('<div class="section-heading">🃏 Player Cards</div>', unsafe_allow_html=True)

    cols = st.columns(4)
    for i, player in enumerate(filtered):
        with cols[i % 4]:
            st.markdown(player_card_html(player), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ─── Detailed Table ───────────────────────────────────────────────────────
    st.markdown('<div class="section-heading">📋 Full Stats Table</div>', unsafe_allow_html=True)

    rows_html = ""
    for i, p in enumerate(filtered):
        color = get_team_color(p.get("team", ""))
        rows_html += f"""
<tr style="border-bottom:1px solid rgba(255,255,255,0.04); transition: background 0.15s;">
  <td style="padding:10px 14px; color:#8888aa; font-size:12px">{i+1}</td>
  <td style="padding:10px 14px;">
    <div style="font-weight:600; color:#f0f0fa; font-size:13px">{p.get('name','')}</div>
    <div style="font-size:11px; color:{color}">{p.get('team','')}</div>
  </td>
  <td style="padding:10px 14px;">
    <span style="background:rgba(232,201,77,0.1); border:1px solid rgba(232,201,77,0.25); color:#e8c94d;
      font-size:10px; padding:2px 8px; border-radius:99px; font-family:Syne,sans-serif; font-weight:600">
      {p.get('role','')}
    </span>
  </td>
  <td style="padding:10px 14px; font-family:Syne,sans-serif; font-size:16px; font-weight:800; color:#e8c94d">{p.get('runs',0)}</td>
  <td style="padding:10px 14px; font-family:Syne,sans-serif; font-size:16px; font-weight:800; color:#00e676">{p.get('wickets',0)}</td>
  <td style="padding:10px 14px; color:#8888aa">{p.get('avg',0.0)}</td>
</tr>"""

    st.markdown(f"""
<div style="background:#111120; border:1px solid rgba(255,255,255,0.07); border-radius:14px; overflow:hidden; overflow-x:auto">
  <table style="width:100%; border-collapse:collapse; font-size:13px; min-width:560px">
    <thead>
      <tr style="background:#1a1a2e; border-bottom:2px solid rgba(232,201,77,0.2)">
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">#</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Player</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Role</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Runs</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Wkts</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Avg</th>
      </tr>
    </thead>
    <tbody>{rows_html}</tbody>
  </table>
</div>
""", unsafe_allow_html=True)

    # ─── Player Profile Expander ──────────────────────────────────────────────
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown('<div class="section-heading">🔎 Player Profile</div>', unsafe_allow_html=True)

    player_names = [p["name"] for p in filtered]
    if player_names:
        selected_name = st.selectbox("Select player for details", player_names, key="ps_profile")
        player = next((p for p in filtered if p["name"] == selected_name), None)
        if player:
            color = get_team_color(player.get("team", ""))
            from utils import avatar_url
            img = player.get("image", "") or avatar_url(player["name"])

            col_img, col_details = st.columns([1, 2])
            with col_img:
                st.markdown(f"""
<div style="text-align:center; padding:20px">
  <img src="{img}" style="width:110px; height:110px; border-radius:50%;
    border:3px solid {color}; object-fit:cover; display:block; margin:0 auto 12px"
    onerror="this.src='{avatar_url(player['name'])}'"/>
  <div style="font-family:Syne,sans-serif; font-size:18px; font-weight:800; color:#f0f0fa">{player['name']}</div>
  <div style="font-size:12px; color:{color}; margin:4px 0">{player.get('team','')}</div>
  <div style="display:inline-block; background:rgba(232,201,77,0.1); border:1px solid rgba(232,201,77,0.25);
    color:#e8c94d; font-size:11px; padding:3px 10px; border-radius:99px; margin-top:6px;
    font-family:Syne,sans-serif; font-weight:600">{player.get('role','')}</div>
</div>""", unsafe_allow_html=True)

            with col_details:
                st.markdown("<br>", unsafe_allow_html=True)
                d1, d2, d3 = st.columns(3)
                for col_s, label, val in [
                    (d1, "🏏 Runs", player.get("runs", 0)),
                    (d2, "🎯 Wickets", player.get("wickets", 0)),
                    (d3, "📊 Batting Avg", player.get("avg", 0.0)),
                ]:
                    with col_s:
                        st.metric(label, val)
