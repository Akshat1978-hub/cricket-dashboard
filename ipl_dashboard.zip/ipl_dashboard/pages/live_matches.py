"""
pages/live_matches.py — Live & Recent Matches Tab
"""

import streamlit as st
from components.cards import match_card_html, win_prob_html, kpi_html
from utils import is_live, is_completed, parse_score, calculate_win_probability, ALL_TEAMS


def render(matches: list, demo_mode: bool = False):
    # ─── KPI Row ──────────────────────────────────────────────────────────────
    live_matches = [m for m in matches if is_live(m)]
    done_matches = [m for m in matches if is_completed(m)]
    total_teams  = len(set(t for m in matches for t in m.get("teams", [])))

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(kpi_html("Live Now", len(live_matches), "matches in progress"), unsafe_allow_html=True)
    with c2:
        st.markdown(kpi_html("Total Matches", len(matches), "this session"), unsafe_allow_html=True)
    with c3:
        st.markdown(kpi_html("Completed", len(done_matches), "finished today"), unsafe_allow_html=True)
    with c4:
        st.markdown(kpi_html("Teams Active", total_teams, "franchises"), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ─── Filter Controls ──────────────────────────────────────────────────────
    col_filter, col_sort = st.columns([3, 1])
    with col_filter:
        team_filter = st.selectbox(
            "Filter by team",
            ["All Teams"] + ALL_TEAMS,
            key="lm_team_filter",
            label_visibility="collapsed",
        )
    with col_sort:
        sort_live_first = st.toggle("🔴 Live first", value=True, key="lm_sort")

    # Apply filter
    filtered = matches
    if team_filter != "All Teams":
        filtered = [m for m in matches if team_filter in m.get("teams", [])]

    if sort_live_first:
        filtered = sorted(filtered, key=lambda m: (0 if is_live(m) else 1, m.get("date", "")))

    if not filtered:
        st.info("No matches found for the selected filter.")
        return

    # ─── Match Cards ──────────────────────────────────────────────────────────
    st.markdown(
        f'<div class="section-heading">🏏 {"Live & Recent" if not team_filter or team_filter == "All Teams" else team_filter} Matches</div>',
        unsafe_allow_html=True,
    )

    col_a, col_b = st.columns(2)
    for i, match in enumerate(filtered):
        col = col_a if i % 2 == 0 else col_b
        with col:
            st.markdown(match_card_html(match), unsafe_allow_html=True)

            # Expandable win probability
            if is_live(match) or is_completed(match):
                with st.expander("📊 Win Probability & Details", expanded=False):
                    scores = parse_score(match.get("score", []))
                    teams  = match.get("teams", ["Team A", "Team B"])

                    if len(scores) >= 2:
                        t1, t2 = teams[0], teams[1] if len(teams) > 1 else "Team B"
                        s1 = scores[0]
                        s2 = scores[1]
                        target = s1["runs"] + 1
                        p1, p2 = calculate_win_probability(
                            t2, s2["runs"], s2["wickets"], s2["overs"], target
                        )
                        st.markdown(win_prob_html(t1, t2, round(100 - p1, 1), p1), unsafe_allow_html=True)
                        st.progress(p1 / 100)
                        st.caption(f"Target: {target} | Req rate: {max(0, (target-s2['runs']))/max(0.1, 20-s2['overs']):.2f}/ov")

                    elif len(scores) == 1:
                        t1, t2 = (teams[0], teams[1]) if len(teams) > 1 else ("Team A", "Team B")
                        s = scores[0]
                        p1, p2 = calculate_win_probability(t1, s["runs"], s["wickets"], s["overs"])
                        st.markdown(win_prob_html(t1, t2, p1, p2), unsafe_allow_html=True)
                        st.progress(p1 / 100)
                    else:
                        st.caption("Scores not yet available.")

                    toss = match.get("toss", {})
                    if toss:
                        st.caption(f"🪙 Toss: {toss.get('winner','')} chose to {toss.get('decision','')}")
