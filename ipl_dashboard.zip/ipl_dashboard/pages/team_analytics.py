"""
pages/team_analytics.py — Team Analytics Tab
"""

import streamlit as st
import plotly.graph_objects as go
from components.charts import team_runs_bar, team_performance_line, team_composition_donut
from utils import ALL_TEAMS, get_team_color, TEAM_META, is_completed, parse_score


def render(matches: list, players: list):
    st.markdown('<div class="section-heading">📊 Team Analytics</div>', unsafe_allow_html=True)

    # ─── Overview Charts ──────────────────────────────────────────────────────
    col1, col2 = st.columns([1, 1])
    with col1:
        fig_bar = team_runs_bar(matches)
        st.plotly_chart(fig_bar, use_container_width=True, config={"displayModeBar": False})
    with col2:
        fig_line = team_performance_line(players)
        st.plotly_chart(fig_line, use_container_width=True, config={"displayModeBar": False})

    st.markdown("<br>", unsafe_allow_html=True)

    # ─── Team Spotlight ───────────────────────────────────────────────────────
    st.markdown('<div class="section-heading">🔍 Team Spotlight</div>', unsafe_allow_html=True)

    teams_with_matches = list({t for m in matches for t in m.get("teams", [])}) or ALL_TEAMS[:5]
    selected_team = st.selectbox("Select a team", sorted(teams_with_matches), key="ta_team")

    if selected_team:
        color    = get_team_color(selected_team)
        meta     = TEAM_META.get(selected_team, {})
        short    = meta.get("short", selected_team[:3].upper())
        emoji    = meta.get("emoji", "🏏")

        # Team KPIs
        team_matches = [m for m in matches if selected_team in m.get("teams", [])]
        wins   = sum(1 for m in team_matches if selected_team in m.get("status", ""))
        losses = len([m for m in team_matches if is_completed(m)]) - wins

        all_scores = []
        for m in team_matches:
            for s in parse_score(m.get("score", [])):
                if selected_team[:8] in s["inning"][:20]:
                    all_scores.append(s["runs"])

        avg_score = round(sum(all_scores) / len(all_scores), 1) if all_scores else "—"
        highest   = max(all_scores, default="—")

        # Team header
        st.markdown(f"""
<div style="
  background: linear-gradient(135deg, {color}18, {color}05);
  border: 1px solid {color}40;
  border-radius: 16px;
  padding: 20px 24px;
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 20px;
">
  <div style="
    width: 64px; height: 64px; background: {color}30;
    border-radius: 14px; display: flex; align-items: center;
    justify-content: center; font-size: 32px; border: 2px solid {color}50;
  ">{emoji}</div>
  <div>
    <div style="font-family: Syne, sans-serif; font-size: 22px; font-weight: 800; color: #f0f0fa;">{selected_team}</div>
    <div style="font-size: 12px; color: {color}; font-weight: 600; letter-spacing: 0.1em;">{short} · IPL 2025</div>
  </div>
</div>""", unsafe_allow_html=True)

        k1, k2, k3, k4 = st.columns(4)
        for col, label, val, sub in [
            (k1, "Matches Played", len(team_matches), "this season"),
            (k2, "Wins", wins, f"W/L: {wins}/{losses}"),
            (k3, "Avg Score", avg_score, "runs per innings"),
            (k4, "Highest Score", highest, "runs in a match"),
        ]:
            with col:
                st.markdown(f"""
<div class="kpi-card">
  <div class="kpi-label">{label}</div>
  <div class="kpi-value" style="font-size:26px;color:{color}">{val}</div>
  <div class="kpi-sub">{sub}</div>
</div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Squad donut + match list
        col_a, col_b = st.columns([1, 1])
        with col_a:
            fig_donut = team_composition_donut(players, selected_team)
            st.plotly_chart(fig_donut, use_container_width=True, config={"displayModeBar": False})
        with col_b:
            st.markdown("**Recent Results**")
            if team_matches:
                for m in team_matches[-4:]:
                    status = m.get("status", "")
                    won = selected_team in status
                    color_dot = "#00e676" if won else "#ff5252"
                    dot = "●"
                    st.markdown(f"""
<div style="
  display:flex; align-items:center; gap:10px;
  background:#161628; border-radius:8px; padding:10px 14px; margin-bottom:6px;
  border:1px solid rgba(255,255,255,0.06);
">
  <span style="color:{color_dot}; font-size:18px">{dot}</span>
  <div>
    <div style="font-size:12px; font-weight:600; color:#f0f0fa">{m.get('name','')[:40]}</div>
    <div style="font-size:11px; color:#8888aa">{m.get('status','')[:50]}</div>
  </div>
</div>""", unsafe_allow_html=True)
            else:
                st.caption("No recent matches found.")

    st.markdown("<br>", unsafe_allow_html=True)

    # ─── Points Table (simulated) ─────────────────────────────────────────────
    st.markdown('<div class="section-heading">🏆 Points Table (Simulated)</div>', unsafe_allow_html=True)

    import random
    random.seed(99)
    table_data = []
    for team in ALL_TEAMS:
        mp = random.randint(6, 12)
        w  = random.randint(2, mp)
        l  = mp - w
        pts = w * 2
        nrr = round(random.uniform(-0.8, 1.5), 3)
        table_data.append({"Team": team, "M": mp, "W": w, "L": l, "Pts": pts, "NRR": nrr})
    table_data.sort(key=lambda x: (-x["Pts"], -x["NRR"]))

    rows_html = ""
    for i, row in enumerate(table_data):
        bg = "rgba(232,201,77,0.07)" if i < 4 else "transparent"
        pos_color = "#e8c94d" if i < 4 else "#8888aa"
        nrr_color = "#00e676" if row["NRR"] >= 0 else "#ff5252"
        rows_html += f"""
<tr style="background:{bg}; border-bottom:1px solid rgba(255,255,255,0.04)">
  <td style="padding:10px 14px; color:{pos_color}; font-family:Syne,sans-serif; font-weight:700">{i+1}</td>
  <td style="padding:10px 14px; color:#f0f0fa; font-weight:600">{row['Team']}</td>
  <td style="padding:10px 14px; color:#8888aa">{row['M']}</td>
  <td style="padding:10px 14px; color:#00e676">{row['W']}</td>
  <td style="padding:10px 14px; color:#ff5252">{row['L']}</td>
  <td style="padding:10px 14px; color:{nrr_color}; font-weight:600">{'+' if row['NRR']>=0 else ''}{row['NRR']}</td>
  <td style="padding:10px 14px; color:#e8c94d; font-family:Syne,sans-serif; font-weight:800; font-size:16px">{row['Pts']}</td>
</tr>"""

    st.markdown(f"""
<div style="background:#111120; border:1px solid rgba(255,255,255,0.07); border-radius:14px; overflow:hidden">
  <table style="width:100%; border-collapse:collapse; font-size:13px">
    <thead>
      <tr style="background:#1a1a2e; border-bottom:2px solid rgba(232,201,77,0.2)">
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">#</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Team</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">M</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">W</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">L</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">NRR</th>
        <th style="padding:12px 14px; color:#8888aa; text-align:left; font-size:10px; text-transform:uppercase; letter-spacing:0.1em">Pts</th>
      </tr>
    </thead>
    <tbody>{rows_html}</tbody>
  </table>
</div>
<div style="font-size:11px; color:#55556a; margin-top:8px;">⭐ Top 4 qualify for playoffs</div>
""", unsafe_allow_html=True)
